const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');

// Create order and payment
router.post('/', orderController.createOrder);

// Get user orders
router.get('/:userId', orderController.getUserOrders);

module.exports = router;