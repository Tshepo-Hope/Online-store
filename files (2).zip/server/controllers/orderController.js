const Stripe = require('stripe');
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

exports.createOrder = async (req, res) => {
  // ... calculate total, etc.
  const charge = await stripe.charges.create({
    amount: Math.round(total * 100),
    currency: 'zar',
    source: token.id,
    description: `Order by user ${userId}`
  });

  // ... save order, send response
};