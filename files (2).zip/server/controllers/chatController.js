const Message = require('../models/Message');

exports.getMessages = async (req, res) => {
  const { userId, otherUserId } = req.params;
  const messages = await Message.find({
    $or: [
      { sender: userId, receiver: otherUserId },
      { sender: otherUserId, receiver: userId }
    ]
  }).sort({ timestamp: 1 });
  res.json(messages);
};